//
//  AppDelegate.h
//  VHLObfuscationDemo
//
//  Created by Vincent on 2018/10/22.
//  Copyright © 2018 Darnel Studio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

