//
//  ViewController.h
//  VHLObfuscationDemo
//
//  Created by Vincent on 2018/10/22.
//  Copyright © 2018 Darnel Studio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (BOOL)vhl_isVip;
- (void)vhl_showsystemInfo;

@end

