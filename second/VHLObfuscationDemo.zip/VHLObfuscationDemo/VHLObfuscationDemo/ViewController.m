//
//  ViewController.m
//  VHLObfuscationDemo
//
//  Created by Vincent on 2018/10/22.
//  Copyright © 2018 Darnel Studio. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)vhl_showsystemInfo {
    NSLog(@"xxxx");
}

-(BOOL)vhl_isVip{
    return YES;
}

@end
