#ifndef Demo_codeObfuscation_h
#define Demo_codeObfuscation_h
//confuse string at Thu Oct 25 18:27:04 CST 2018
#define vhl_isVip wveVFTtnsCAckOWx
#define vhl_showsystemInfo gXXmZPcRYwTZfqYy
#endif
